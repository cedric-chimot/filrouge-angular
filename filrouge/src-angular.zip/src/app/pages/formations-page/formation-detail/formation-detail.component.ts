import { Component } from '@angular/core';

@Component({
  selector: 'app-formation-detail',
  standalone: true,
  imports: [],
  templateUrl: './formation-detail.component.html',
  styleUrl: './formation-detail.component.css'
})
export class FormationDetailComponent {

}
