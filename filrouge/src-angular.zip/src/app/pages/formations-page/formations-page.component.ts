import { Component } from '@angular/core';

@Component({
  selector: 'app-formations-page',
  standalone: true,
  imports: [],
  templateUrl: './formations-page.component.html',
  styleUrl: './formations-page.component.css'
})
export class FormationsPageComponent {

}
