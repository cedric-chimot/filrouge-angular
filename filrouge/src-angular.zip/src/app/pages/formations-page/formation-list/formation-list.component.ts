import { Component } from '@angular/core';

@Component({
  selector: 'app-formation-list',
  standalone: true,
  imports: [],
  templateUrl: './formation-list.component.html',
  styleUrl: './formation-list.component.css'
})
export class FormationListComponent {

}
